<?php
// 数据库配置，仅返回数组
return [
    'host' => 'localhost', // 修改为你的数据库主机
    'user' => 'root',      // 修改为你的数据库用户名
    'pass' => '',          // 修改为你的数据库密码
    'name' => 'test'       // 修改为你的数据库名
];
